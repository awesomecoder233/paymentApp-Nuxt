import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _20a72714 = () => interopDefault(import('..\\pages\\debug\\index.vue' /* webpackChunkName: "pages_debug_index" */))
const _2addc8ae = () => interopDefault(import('..\\pages\\home\\index.vue' /* webpackChunkName: "pages_home_index" */))
const _67625b5c = () => interopDefault(import('..\\pages\\auth\\login.vue' /* webpackChunkName: "pages_auth_login" */))
const _b80601da = () => interopDefault(import('..\\pages\\debug\\businessAccount\\index.vue' /* webpackChunkName: "pages_debug_businessAccount_index" */))
const _a10ff474 = () => interopDefault(import('..\\pages\\debug\\digitalDollarAccounts\\index.vue' /* webpackChunkName: "pages_debug_digitalDollarAccounts_index" */))
const _661fffd3 = () => interopDefault(import('..\\pages\\debug\\payouts\\index.vue' /* webpackChunkName: "pages_debug_payouts_index" */))
const _264611a6 = () => interopDefault(import('..\\pages\\debug\\wallets\\index.vue' /* webpackChunkName: "pages_debug_wallets_index" */))
const _4c3ead6a = () => interopDefault(import('..\\pages\\flow\\charge\\index.vue' /* webpackChunkName: "pages_flow_charge_index" */))
const _60e05dc4 = () => interopDefault(import('..\\pages\\debug\\ach\\create.vue' /* webpackChunkName: "pages_debug_ach_create" */))
const _6210d1aa = () => interopDefault(import('..\\pages\\debug\\ach\\details.vue' /* webpackChunkName: "pages_debug_ach_details" */))
const _02c4c6a1 = () => interopDefault(import('..\\pages\\debug\\cards\\create.vue' /* webpackChunkName: "pages_debug_cards_create" */))
const _068cf726 = () => interopDefault(import('..\\pages\\debug\\cards\\details.vue' /* webpackChunkName: "pages_debug_cards_details" */))
const _35a0b4b6 = () => interopDefault(import('..\\pages\\debug\\cards\\fetch.vue' /* webpackChunkName: "pages_debug_cards_fetch" */))
const _c0f6a024 = () => interopDefault(import('..\\pages\\debug\\cards\\update.vue' /* webpackChunkName: "pages_debug_cards_update" */))
const _48c61f38 = () => interopDefault(import('..\\pages\\debug\\chargebacks\\details.vue' /* webpackChunkName: "pages_debug_chargebacks_details" */))
const _24aa7730 = () => interopDefault(import('..\\pages\\debug\\chargebacks\\fetch.vue' /* webpackChunkName: "pages_debug_chargebacks_fetch" */))
const _8c607f56 = () => interopDefault(import('..\\pages\\debug\\payments\\cancel.vue' /* webpackChunkName: "pages_debug_payments_cancel" */))
const _2ba77a0a = () => interopDefault(import('..\\pages\\debug\\payments\\capture.vue' /* webpackChunkName: "pages_debug_payments_capture" */))
const _ca4bbc52 = () => interopDefault(import('..\\pages\\debug\\payments\\create.vue' /* webpackChunkName: "pages_debug_payments_create" */))
const _674f8ff7 = () => interopDefault(import('..\\pages\\debug\\payments\\details.vue' /* webpackChunkName: "pages_debug_payments_details" */))
const _aff1e8a2 = () => interopDefault(import('..\\pages\\debug\\payments\\fetch.vue' /* webpackChunkName: "pages_debug_payments_fetch" */))
const _397e7b5a = () => interopDefault(import('..\\pages\\debug\\payments\\refund.vue' /* webpackChunkName: "pages_debug_payments_refund" */))
const _f4d7756a = () => interopDefault(import('..\\pages\\debug\\payouts\\create.vue' /* webpackChunkName: "pages_debug_payouts_create" */))
const _584c49fa = () => interopDefault(import('..\\pages\\debug\\payouts\\details.vue' /* webpackChunkName: "pages_debug_payouts_details" */))
const _4c80a9bb = () => interopDefault(import('..\\pages\\debug\\payouts\\fetch.vue' /* webpackChunkName: "pages_debug_payouts_fetch" */))
const _e228eb76 = () => interopDefault(import('..\\pages\\debug\\returns\\fetch.vue' /* webpackChunkName: "pages_debug_returns_fetch" */))
const _cb34683a = () => interopDefault(import('..\\pages\\debug\\reversals\\fetch.vue' /* webpackChunkName: "pages_debug_reversals_fetch" */))
const _5479aa46 = () => interopDefault(import('..\\pages\\debug\\settlements\\details.vue' /* webpackChunkName: "pages_debug_settlements_details" */))
const _3a416dbe = () => interopDefault(import('..\\pages\\debug\\settlements\\fetch.vue' /* webpackChunkName: "pages_debug_settlements_fetch" */))
const _3e76d74c = () => interopDefault(import('..\\pages\\debug\\wires\\create.vue' /* webpackChunkName: "pages_debug_wires_create" */))
const _37498922 = () => interopDefault(import('..\\pages\\debug\\wires\\details.vue' /* webpackChunkName: "pages_debug_wires_details" */))
const _a7e19516 = () => interopDefault(import('..\\pages\\debug\\wires\\instructions.vue' /* webpackChunkName: "pages_debug_wires_instructions" */))
const _eff7cc9a = () => interopDefault(import('..\\pages\\flow\\card\\create\\index.vue' /* webpackChunkName: "pages_flow_card_create_index" */))
const _5d367c97 = () => interopDefault(import('..\\pages\\flow\\charge\\existing-card\\index.vue' /* webpackChunkName: "pages_flow_charge_existing-card_index" */))
const _5f9da58d = () => interopDefault(import('..\\pages\\debug\\ach\\mocks\\create.vue' /* webpackChunkName: "pages_debug_ach_mocks_create" */))
const _92784678 = () => interopDefault(import('..\\pages\\debug\\businessAccount\\balances\\fetch.vue' /* webpackChunkName: "pages_debug_businessAccount_balances_fetch" */))
const _729e148d = () => interopDefault(import('..\\pages\\debug\\businessAccount\\bankAccounts\\create.vue' /* webpackChunkName: "pages_debug_businessAccount_bankAccounts_create" */))
const _efec17fe = () => interopDefault(import('..\\pages\\debug\\businessAccount\\bankAccounts\\details.vue' /* webpackChunkName: "pages_debug_businessAccount_bankAccounts_details" */))
const _91822b8e = () => interopDefault(import('..\\pages\\debug\\businessAccount\\bankAccounts\\fetch.vue' /* webpackChunkName: "pages_debug_businessAccount_bankAccounts_fetch" */))
const _3189bdf6 = () => interopDefault(import('..\\pages\\debug\\businessAccount\\bankAccounts\\instructions.vue' /* webpackChunkName: "pages_debug_businessAccount_bankAccounts_instructions" */))
const _032af186 = () => interopDefault(import('..\\pages\\debug\\businessAccount\\deposits\\fetch.vue' /* webpackChunkName: "pages_debug_businessAccount_deposits_fetch" */))
const _04976a8a = () => interopDefault(import('..\\pages\\debug\\businessAccount\\payouts\\create.vue' /* webpackChunkName: "pages_debug_businessAccount_payouts_create" */))
const _353b5da4 = () => interopDefault(import('..\\pages\\debug\\businessAccount\\payouts\\details.vue' /* webpackChunkName: "pages_debug_businessAccount_payouts_details" */))
const _88173ec8 = () => interopDefault(import('..\\pages\\debug\\businessAccount\\payouts\\fetch.vue' /* webpackChunkName: "pages_debug_businessAccount_payouts_fetch" */))
const _3494f225 = () => interopDefault(import('..\\pages\\debug\\businessAccount\\transfers\\create.vue' /* webpackChunkName: "pages_debug_businessAccount_transfers_create" */))
const _04eec969 = () => interopDefault(import('..\\pages\\debug\\businessAccount\\transfers\\details.vue' /* webpackChunkName: "pages_debug_businessAccount_transfers_details" */))
const _62a9f9a1 = () => interopDefault(import('..\\pages\\debug\\businessAccount\\transfers\\fetch.vue' /* webpackChunkName: "pages_debug_businessAccount_transfers_fetch" */))
const _421a109b = () => interopDefault(import('..\\pages\\debug\\chargebacks\\mocks\\create.vue' /* webpackChunkName: "pages_debug_chargebacks_mocks_create" */))
const _21348b08 = () => interopDefault(import('..\\pages\\debug\\marketplace\\merchants\\fetch.vue' /* webpackChunkName: "pages_debug_marketplace_merchants_fetch" */))
const _7d58d574 = () => interopDefault(import('..\\pages\\debug\\marketplace\\payments\\cancel.vue' /* webpackChunkName: "pages_debug_marketplace_payments_cancel" */))
const _d0745c88 = () => interopDefault(import('..\\pages\\debug\\marketplace\\payments\\capture.vue' /* webpackChunkName: "pages_debug_marketplace_payments_capture" */))
const _5e6336f6 = () => interopDefault(import('..\\pages\\debug\\marketplace\\payments\\create.vue' /* webpackChunkName: "pages_debug_marketplace_payments_create" */))
const _14e91eb8 = () => interopDefault(import('..\\pages\\debug\\marketplace\\payments\\details.vue' /* webpackChunkName: "pages_debug_marketplace_payments_details" */))
const _748756b0 = () => interopDefault(import('..\\pages\\debug\\marketplace\\payments\\fetch.vue' /* webpackChunkName: "pages_debug_marketplace_payments_fetch" */))
const _b26c511c = () => interopDefault(import('..\\pages\\debug\\marketplace\\payments\\refund.vue' /* webpackChunkName: "pages_debug_marketplace_payments_refund" */))
const _5b2f2310 = () => interopDefault(import('..\\pages\\debug\\payments\\balances\\fetch.vue' /* webpackChunkName: "pages_debug_payments_balances_fetch" */))
const _aa557aba = () => interopDefault(import('..\\pages\\debug\\payments\\mocks\\wire.vue' /* webpackChunkName: "pages_debug_payments_mocks_wire" */))
const _1afd2ef2 = () => interopDefault(import('..\\pages\\debug\\wallets\\addresses\\create.vue' /* webpackChunkName: "pages_debug_wallets_addresses_create" */))
const _49106f34 = () => interopDefault(import('..\\pages\\debug\\wallets\\addresses\\fetch.vue' /* webpackChunkName: "pages_debug_wallets_addresses_fetch" */))
const _85e07f90 = () => interopDefault(import('..\\pages\\debug\\wallets\\transfers\\create.vue' /* webpackChunkName: "pages_debug_wallets_transfers_create" */))
const _e8648494 = () => interopDefault(import('..\\pages\\debug\\wallets\\transfers\\details.vue' /* webpackChunkName: "pages_debug_wallets_transfers_details" */))
const _9d38c5a4 = () => interopDefault(import('..\\pages\\debug\\wallets\\transfers\\fetch.vue' /* webpackChunkName: "pages_debug_wallets_transfers_fetch" */))
const _4fbe6c2c = () => interopDefault(import('..\\pages\\debug\\wallets\\wallets\\create.vue' /* webpackChunkName: "pages_debug_wallets_wallets_create" */))
const _5a442b78 = () => interopDefault(import('..\\pages\\debug\\wallets\\wallets\\details.vue' /* webpackChunkName: "pages_debug_wallets_wallets_details" */))
const _27dcd588 = () => interopDefault(import('..\\pages\\debug\\wallets\\wallets\\fetch.vue' /* webpackChunkName: "pages_debug_wallets_wallets_fetch" */))
const _194cd3c7 = () => interopDefault(import('..\\pages\\debug\\businessAccount\\addresses\\deposit\\create.vue' /* webpackChunkName: "pages_debug_businessAccount_addresses_deposit_create" */))
const _387e5bbf = () => interopDefault(import('..\\pages\\debug\\businessAccount\\addresses\\deposit\\fetch.vue' /* webpackChunkName: "pages_debug_businessAccount_addresses_deposit_fetch" */))
const _1fc8dd82 = () => interopDefault(import('..\\pages\\debug\\businessAccount\\addresses\\recipient\\create.vue' /* webpackChunkName: "pages_debug_businessAccount_addresses_recipient_create" */))
const _c866a2b8 = () => interopDefault(import('..\\pages\\debug\\businessAccount\\addresses\\recipient\\fetch.vue' /* webpackChunkName: "pages_debug_businessAccount_addresses_recipient_fetch" */))
const _52636ea6 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/debug",
    component: _20a72714,
    name: "debug"
  }, {
    path: "/home",
    component: _2addc8ae,
    name: "home"
  }, {
    path: "/auth/login",
    component: _67625b5c,
    name: "auth-login"
  }, {
    path: "/debug/businessAccount",
    component: _b80601da,
    name: "debug-businessAccount"
  }, {
    path: "/debug/digitalDollarAccounts",
    component: _a10ff474,
    name: "debug-digitalDollarAccounts"
  }, {
    path: "/debug/payouts",
    component: _661fffd3,
    name: "debug-payouts"
  }, {
    path: "/debug/wallets",
    component: _264611a6,
    name: "debug-wallets"
  }, {
    path: "/flow/charge",
    component: _4c3ead6a,
    name: "flow-charge"
  }, {
    path: "/debug/ach/create",
    component: _60e05dc4,
    name: "debug-ach-create"
  }, {
    path: "/debug/ach/details",
    component: _6210d1aa,
    name: "debug-ach-details"
  }, {
    path: "/debug/cards/create",
    component: _02c4c6a1,
    name: "debug-cards-create"
  }, {
    path: "/debug/cards/details",
    component: _068cf726,
    name: "debug-cards-details"
  }, {
    path: "/debug/cards/fetch",
    component: _35a0b4b6,
    name: "debug-cards-fetch"
  }, {
    path: "/debug/cards/update",
    component: _c0f6a024,
    name: "debug-cards-update"
  }, {
    path: "/debug/chargebacks/details",
    component: _48c61f38,
    name: "debug-chargebacks-details"
  }, {
    path: "/debug/chargebacks/fetch",
    component: _24aa7730,
    name: "debug-chargebacks-fetch"
  }, {
    path: "/debug/payments/cancel",
    component: _8c607f56,
    name: "debug-payments-cancel"
  }, {
    path: "/debug/payments/capture",
    component: _2ba77a0a,
    name: "debug-payments-capture"
  }, {
    path: "/debug/payments/create",
    component: _ca4bbc52,
    name: "debug-payments-create"
  }, {
    path: "/debug/payments/details",
    component: _674f8ff7,
    name: "debug-payments-details"
  }, {
    path: "/debug/payments/fetch",
    component: _aff1e8a2,
    name: "debug-payments-fetch"
  }, {
    path: "/debug/payments/refund",
    component: _397e7b5a,
    name: "debug-payments-refund"
  }, {
    path: "/debug/payouts/create",
    component: _f4d7756a,
    name: "debug-payouts-create"
  }, {
    path: "/debug/payouts/details",
    component: _584c49fa,
    name: "debug-payouts-details"
  }, {
    path: "/debug/payouts/fetch",
    component: _4c80a9bb,
    name: "debug-payouts-fetch"
  }, {
    path: "/debug/returns/fetch",
    component: _e228eb76,
    name: "debug-returns-fetch"
  }, {
    path: "/debug/reversals/fetch",
    component: _cb34683a,
    name: "debug-reversals-fetch"
  }, {
    path: "/debug/settlements/details",
    component: _5479aa46,
    name: "debug-settlements-details"
  }, {
    path: "/debug/settlements/fetch",
    component: _3a416dbe,
    name: "debug-settlements-fetch"
  }, {
    path: "/debug/wires/create",
    component: _3e76d74c,
    name: "debug-wires-create"
  }, {
    path: "/debug/wires/details",
    component: _37498922,
    name: "debug-wires-details"
  }, {
    path: "/debug/wires/instructions",
    component: _a7e19516,
    name: "debug-wires-instructions"
  }, {
    path: "/flow/card/create",
    component: _eff7cc9a,
    name: "flow-card-create"
  }, {
    path: "/flow/charge/existing-card",
    component: _5d367c97,
    name: "flow-charge-existing-card"
  }, {
    path: "/debug/ach/mocks/create",
    component: _5f9da58d,
    name: "debug-ach-mocks-create"
  }, {
    path: "/debug/businessAccount/balances/fetch",
    component: _92784678,
    name: "debug-businessAccount-balances-fetch"
  }, {
    path: "/debug/businessAccount/bankAccounts/create",
    component: _729e148d,
    name: "debug-businessAccount-bankAccounts-create"
  }, {
    path: "/debug/businessAccount/bankAccounts/details",
    component: _efec17fe,
    name: "debug-businessAccount-bankAccounts-details"
  }, {
    path: "/debug/businessAccount/bankAccounts/fetch",
    component: _91822b8e,
    name: "debug-businessAccount-bankAccounts-fetch"
  }, {
    path: "/debug/businessAccount/bankAccounts/instructions",
    component: _3189bdf6,
    name: "debug-businessAccount-bankAccounts-instructions"
  }, {
    path: "/debug/businessAccount/deposits/fetch",
    component: _032af186,
    name: "debug-businessAccount-deposits-fetch"
  }, {
    path: "/debug/businessAccount/payouts/create",
    component: _04976a8a,
    name: "debug-businessAccount-payouts-create"
  }, {
    path: "/debug/businessAccount/payouts/details",
    component: _353b5da4,
    name: "debug-businessAccount-payouts-details"
  }, {
    path: "/debug/businessAccount/payouts/fetch",
    component: _88173ec8,
    name: "debug-businessAccount-payouts-fetch"
  }, {
    path: "/debug/businessAccount/transfers/create",
    component: _3494f225,
    name: "debug-businessAccount-transfers-create"
  }, {
    path: "/debug/businessAccount/transfers/details",
    component: _04eec969,
    name: "debug-businessAccount-transfers-details"
  }, {
    path: "/debug/businessAccount/transfers/fetch",
    component: _62a9f9a1,
    name: "debug-businessAccount-transfers-fetch"
  }, {
    path: "/debug/chargebacks/mocks/create",
    component: _421a109b,
    name: "debug-chargebacks-mocks-create"
  }, {
    path: "/debug/marketplace/merchants/fetch",
    component: _21348b08,
    name: "debug-marketplace-merchants-fetch"
  }, {
    path: "/debug/marketplace/payments/cancel",
    component: _7d58d574,
    name: "debug-marketplace-payments-cancel"
  }, {
    path: "/debug/marketplace/payments/capture",
    component: _d0745c88,
    name: "debug-marketplace-payments-capture"
  }, {
    path: "/debug/marketplace/payments/create",
    component: _5e6336f6,
    name: "debug-marketplace-payments-create"
  }, {
    path: "/debug/marketplace/payments/details",
    component: _14e91eb8,
    name: "debug-marketplace-payments-details"
  }, {
    path: "/debug/marketplace/payments/fetch",
    component: _748756b0,
    name: "debug-marketplace-payments-fetch"
  }, {
    path: "/debug/marketplace/payments/refund",
    component: _b26c511c,
    name: "debug-marketplace-payments-refund"
  }, {
    path: "/debug/payments/balances/fetch",
    component: _5b2f2310,
    name: "debug-payments-balances-fetch"
  }, {
    path: "/debug/payments/mocks/wire",
    component: _aa557aba,
    name: "debug-payments-mocks-wire"
  }, {
    path: "/debug/wallets/addresses/create",
    component: _1afd2ef2,
    name: "debug-wallets-addresses-create"
  }, {
    path: "/debug/wallets/addresses/fetch",
    component: _49106f34,
    name: "debug-wallets-addresses-fetch"
  }, {
    path: "/debug/wallets/transfers/create",
    component: _85e07f90,
    name: "debug-wallets-transfers-create"
  }, {
    path: "/debug/wallets/transfers/details",
    component: _e8648494,
    name: "debug-wallets-transfers-details"
  }, {
    path: "/debug/wallets/transfers/fetch",
    component: _9d38c5a4,
    name: "debug-wallets-transfers-fetch"
  }, {
    path: "/debug/wallets/wallets/create",
    component: _4fbe6c2c,
    name: "debug-wallets-wallets-create"
  }, {
    path: "/debug/wallets/wallets/details",
    component: _5a442b78,
    name: "debug-wallets-wallets-details"
  }, {
    path: "/debug/wallets/wallets/fetch",
    component: _27dcd588,
    name: "debug-wallets-wallets-fetch"
  }, {
    path: "/debug/businessAccount/addresses/deposit/create",
    component: _194cd3c7,
    name: "debug-businessAccount-addresses-deposit-create"
  }, {
    path: "/debug/businessAccount/addresses/deposit/fetch",
    component: _387e5bbf,
    name: "debug-businessAccount-addresses-deposit-fetch"
  }, {
    path: "/debug/businessAccount/addresses/recipient/create",
    component: _1fc8dd82,
    name: "debug-businessAccount-addresses-recipient-create"
  }, {
    path: "/debug/businessAccount/addresses/recipient/fetch",
    component: _c866a2b8,
    name: "debug-businessAccount-addresses-recipient-fetch"
  }, {
    path: "/",
    component: _52636ea6,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
