export default {"theme":{"themes":{"light":{"primary":"#26a69a","accent":"#26c6da","secondary":"#80cbc4","info":"#80cbc4","warning":"#ffc107","error":"#dd2c00","success":"#00e676"}}}}
