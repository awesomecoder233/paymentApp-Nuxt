export async function loginAccont(params) {
  console.log(params)
  return 'aaa'
}

exports.postLogin = (req, res) => {
  console.log(req.body)
}
